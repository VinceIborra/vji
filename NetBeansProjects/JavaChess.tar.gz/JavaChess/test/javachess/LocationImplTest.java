/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author vji
 */
public class LocationImplTest {

    public LocationImplTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of setRowId method, of class LocationImpl.
     */
    @Test
    public void testSetRowId() {
        System.out.println("setRowId");
        int rowId = 3;
        LocationImpl instance = new LocationImpl();
        instance.setRowId(rowId);
        assertEquals(3, instance.getRowId());
    }

    /**
     * Test of getRowId method, of class LocationImpl.
     */
    @Test
    public void testGetRowId() {
        System.out.println("getRowId");
        int rowId = 3;
        LocationImpl instance = new LocationImpl();
        instance.setRowId(rowId);
        assertEquals(3, instance.getRowId());
    }

    /**
     * Test of setColId method, of class LocationImpl.
     */
    @Test
    public void testSetColId() {
        System.out.println("setColId");
        int colId = 4;
        LocationImpl instance = new LocationImpl();
        instance.setColId(colId);
        assertEquals(4, instance.getColId());
    }

    /**
     * Test of getColId method, of class LocationImpl.
     */
    @Test
    public void testGetColId() {
        System.out.println("getColId");
        int colId = 4;
        LocationImpl instance = new LocationImpl();
        instance.setColId(colId);
        assertEquals(4, instance.getColId());
    }

    /**
     * Test of setPiece method, of class LocationImpl.
     */
    @Test
    public void testSetPiece() {
        System.out.println("setPiece");
        ChessFactory factory = new ChessFactoryImpl();
        Piece piece = factory.makeKingPiece(Team.BLACK);
        LocationImpl instance = new LocationImpl();
        instance.setPiece(piece);
        assertEquals(piece, instance.getPiece());
    }

    /**
     * Test of getPiece method, of class LocationImpl.
     */
    @Test
    public void testGetPiece() {
        System.out.println("getPiece");
        ChessFactory factory = new ChessFactoryImpl();
        Piece piece = factory.makeKingPiece(Team.BLACK);
        LocationImpl instance = new LocationImpl();
        instance.setPiece(piece);
        assertEquals(piece, instance.getPiece());
    }

    /**
     * Test of equals method, of class LocationImpl.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        ChessFactory factory = new ChessFactoryImpl();
        Object obj = factory.makeLocation(3, 4);
        LocationImpl instance = new LocationImpl();
        instance.setRowId(3);
        instance.setColId(4);
        boolean expResult = true;
        boolean result = instance.equals(obj);
        assertEquals(expResult, result);
    }

}