package javachess;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author vji
 */
public class TeamTest {

    public TeamTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of values method, of class ChessTeam.
     */
    @Test
    public void testValues() {
        System.out.println("values");
        Team[] expResult = new Team[2];
        expResult[0] = Team.BLACK;
        expResult[1] = Team.WHITE;
        Team[] result = Team.values();
        assertArrayEquals(expResult, result);
    }

    /**
     * Test of valueOf method, of class ChessTeam.
     */
    @Test
    public void testValueOf() {
        System.out.println("valueOf");
        String name = "BLACK";
        Team expResult = Team.BLACK;
        Team result = Team.valueOf(name);
        assertEquals(expResult, result);

        name = "WHITE";
        expResult = Team.WHITE;
        result = Team.valueOf(name);
        assertEquals(expResult, result);
    }

}