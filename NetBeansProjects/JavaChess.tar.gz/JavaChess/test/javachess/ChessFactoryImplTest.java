/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author vji
 */
public class ChessFactoryImplTest {

    public ChessFactoryImplTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of makeLocation method, of class ChessFactoryImpl.
     */
    @Test
    public void testMakeLocation() {
        System.out.println("makeLocation");
        int rowId = 3;
        int colId = 4;
        ChessFactoryImpl instance = new ChessFactoryImpl();
        LocationImpl expResult = new LocationImpl();
        expResult.setRowId(rowId);
        expResult.setColId(colId);
        Location result = instance.makeLocation(rowId, colId);
        assertEquals(expResult, result);
    }

    /**
     * Test of makeKingPiece method, of class ChessFactoryImpl.
     */
    @Test
    public void testMakeKingPiece() {
        System.out.println("makeKingPiece");
        Team team = Team.BLACK;
        ChessFactoryImpl instance = new ChessFactoryImpl();
        KingPieceImpl expResult = new KingPieceImpl();
        expResult.setTeam(team);
        Piece result = instance.makeKingPiece(team);
        assertEquals(expResult, result);
    }

    /**
     * Test of makeQueenPiece method, of class ChessFactoryImpl.
     */
    @Test
    public void testMakeQueenPiece() {
        System.out.println("makeQueenPiece");
        Team team = Team.BLACK;
        ChessFactoryImpl instance = new ChessFactoryImpl();
        QueenPieceImpl expResult = new QueenPieceImpl();
        expResult.setTeam(team);
        Piece result = instance.makeQueenPiece(team);
        assertEquals(expResult, result);
    }

    /**
     * Test of makeBishopPiece method, of class ChessFactoryImpl.
     */
    @Test
    public void testMakeBishopPiece() {
        System.out.println("makeBishopPiece");
        Team team = Team.BLACK;
        ChessFactoryImpl instance = new ChessFactoryImpl();
        BishopPieceImpl expResult = new BishopPieceImpl();
        expResult.setTeam(team);
        Piece result = instance.makeBishopPiece(team);
        assertEquals(expResult, result);
    }

    /**
     * Test of makeRookPiece method, of class ChessFactoryImpl.
     */
    @Test
    public void testMakeRookPiece() {
        System.out.println("makeRookPiece");
        Team team = Team.BLACK;
        ChessFactoryImpl instance = new ChessFactoryImpl();
        RookPieceImpl expResult = new RookPieceImpl();
        expResult.setTeam(team);
        Piece result = instance.makeRookPiece(team);
        assertEquals(expResult, result);
    }

    /**
     * Test of makePawnPiece method, of class ChessFactoryImpl.
     */
    @Test
    public void testMakePawnPiece() {
        System.out.println("makePawnPiece");
        Team team = Team.BLACK;
        ChessFactoryImpl instance = new ChessFactoryImpl();
        PawnPieceImpl expResult = new PawnPieceImpl();
        expResult.setTeam(team);
        Piece result = instance.makePawnPiece(team);
        assertEquals(expResult, result);
    }

}