/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author vji
 */
public class ChessBoardImplTest {

    public ChessBoardImplTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of setChessFactory method, of class ChessBoardImpl.
     */
    @Test
    public void testSetChessFactory() {
        System.out.println("setChessFactory");
        ChessFactory chessFactory = new ChessFactoryImpl();
        ChessBoardImpl instance = new ChessBoardImpl();
        instance.setChessFactory(chessFactory);
        assertEquals(chessFactory, instance.getChessFactory());
    }

    /**
     * Test of getChessFactory method, of class ChessBoardImpl.
     */
    @Test
    public void testGetChessFactory() {
        System.out.println("getChessFactory");
        ChessFactory chessFactory = new ChessFactoryImpl();
        ChessBoardImpl instance = new ChessBoardImpl();
        instance.setChessFactory(chessFactory);
        assertEquals(chessFactory, instance.getChessFactory());
    }

    private void _assertStandardLocations(Location [][] board) {

        assertEquals(8, board.length);
        for (int idx = 0; idx<8; idx++) {
            assertNotNull(board[idx]);
            assertEquals(8, board[idx].length);
            for (int jdx=0; jdx<8; jdx++) {
                Location location = board[idx][jdx];
                assertNotNull(location);
                assertEquals(idx, location.getRowId());
                assertEquals(jdx, location.getColId());
                Piece piece = location.getPiece();
                switch (idx) {
                    case 0:
                        assertNotNull(piece);
                        assertEquals(Team.BLACK, piece.getTeam());
                        switch (jdx) {
                            case 0: assert(piece instanceof RookPiece);   break;
                            case 1: assert(piece instanceof KnightPiece); break;
                            case 2: assert(piece instanceof BishopPiece); break;
                            case 3: assert(piece instanceof QueenPiece);  break;
                            case 4: assert(piece instanceof KingPiece);   break;
                            case 5: assert(piece instanceof BishopPiece); break;
                            case 6: assert(piece instanceof KnightPiece); break;
                            case 7: assert(piece instanceof RookPiece);   break;
                        }
                        break;
                    case 1:
                        assertNotNull(piece);
                        assertEquals(Team.BLACK, piece.getTeam());
                        switch (jdx) {
                            case 0: assert(piece instanceof PawnPiece); break;
                            case 1: assert(piece instanceof PawnPiece); break;
                            case 2: assert(piece instanceof PawnPiece); break;
                            case 3: assert(piece instanceof PawnPiece); break;
                            case 4: assert(piece instanceof PawnPiece); break;
                            case 5: assert(piece instanceof PawnPiece); break;
                            case 6: assert(piece instanceof PawnPiece); break;
                            case 7: assert(piece instanceof PawnPiece); break;
                        }
                        break;
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        assertNull(piece);
                        break;
                    case 6:
                        assertNotNull(piece);
                        assertEquals(Team.WHITE, piece.getTeam());
                        switch (jdx) {
                            case 0: assert(piece instanceof PawnPiece); break;
                            case 1: assert(piece instanceof PawnPiece); break;
                            case 2: assert(piece instanceof PawnPiece); break;
                            case 3: assert(piece instanceof PawnPiece); break;
                            case 4: assert(piece instanceof PawnPiece); break;
                            case 5: assert(piece instanceof PawnPiece); break;
                            case 6: assert(piece instanceof PawnPiece); break;
                            case 7: assert(piece instanceof PawnPiece); break;
                        }
                        break;
                    case 7:
                        assertNotNull(piece);
                        assertEquals(Team.WHITE, piece.getTeam());
                        switch (jdx) {
                            case 0: assert(piece instanceof RookPiece);   break;
                            case 1: assert(piece instanceof KnightPiece); break;
                            case 2: assert(piece instanceof BishopPiece); break;
                            case 3: assert(piece instanceof QueenPiece);  break;
                            case 4: assert(piece instanceof KingPiece);   break;
                            case 5: assert(piece instanceof BishopPiece); break;
                            case 6: assert(piece instanceof KnightPiece); break;
                            case 7: assert(piece instanceof RookPiece);   break;
                        }
                        break;
                }
            }
        }
    }

    /**
     * Test of getAllLocations method, of class ChessBoardImpl.
     */
    @Test
    public void testGetAllLocations() {
        System.out.println("getAllLocations");
        ChessBoardImpl instance = new ChessBoardImpl();
        ChessFactoryImpl factory = new ChessFactoryImpl();
        instance.setChessFactory(factory);
        instance.resetBoard();
        Location[][] expResult = null;
        Location[][] result = instance.getAllLocations();
        _assertStandardLocations(result);
    }

    /**
     * Test of getLocationAtIds method, of class ChessBoardImpl.
     */
    @Test
    public void testGetLocationAtIds() {
        System.out.println("getLocationAtIds");
        int rowId = 3;
        int colId = 4;
        ChessBoardImpl instance = new ChessBoardImpl();
        ChessFactoryImpl factory = new ChessFactoryImpl();
        instance.setChessFactory(factory);
        instance.resetBoard();
        LocationImpl expResult = new LocationImpl();
        expResult.setColId(colId);
        expResult.setRowId(rowId);
        Location result = instance.getLocationAtIds(rowId, colId);
        assertEquals(expResult, result);
    }

    /**
     * Test of getLocationAtIds method, of class ChessBoardImpl.
     */
    @Test(expected=InvalidIdsException.class)
    public void testGetLocationAtIds_WithInvalidIds() {
        System.out.println("getLocationAtIds with invalid ids");
        int rowId = 9;
        int colId = 9;
        ChessBoardImpl instance = new ChessBoardImpl();
        ChessFactoryImpl factory = new ChessFactoryImpl();
        instance.setChessFactory(factory);
        instance.resetBoard();
        LocationImpl expResult = new LocationImpl();
        expResult.setColId(colId);
        expResult.setRowId(rowId);
        Location result = instance.getLocationAtIds(rowId, colId);
    }

    /**
     * Test of getPieceAtLocation method, of class ChessBoardImpl.
     */
    @Test
    public void testGetPieceAtLocation() {
        System.out.println("getPieceAtLocation");
        ChessBoardImpl instance = new ChessBoardImpl();
        ChessFactoryImpl factory = new ChessFactoryImpl();
        instance.setChessFactory(factory);
        instance.resetBoard();
        Location location = factory.makeLocation(0, 0);
        Piece result = instance.getPieceAtLocation(location);
        assert(result instanceof RookPiece);
    }

    /**
     * Test of getPieceAtLocation method, of class ChessBoardImpl.
     */
    @Test(expected=NullPointerException.class)
    public void testGetPieceAtLocation_WithNullLocation() {
        System.out.println("getPieceAtLocation with null location");
        ChessBoardImpl instance = new ChessBoardImpl();
        ChessFactoryImpl factory = new ChessFactoryImpl();
        instance.setChessFactory(factory);
        instance.resetBoard();
        Piece result = instance.getPieceAtLocation(null);
    }

    /**
     * Test of typeOfPieceAtLocation method, of class ChessBoardImpl.
     */
    @Test
    public void testTypeOfPieceAtLocation() {
        System.out.println("typeOfPieceAtLocation");
        ChessBoardImpl instance = new ChessBoardImpl();
        ChessFactoryImpl factory = new ChessFactoryImpl();
        instance.setChessFactory(factory);
        instance.resetBoard();
        Location location = factory.makeLocation(0, 0);
        Class expResult = RookPiece.class;
        Class result = instance.typeOfPieceAtLocation(location);
        assertEquals(expResult, result);
    }

    /**
     * Test of moveChessPiece method, of class ChessBoardImpl.
     */
    @Test
    public void testMoveChessPiece() {
        System.out.println("moveChessPiece");
        ChessBoardImpl instance = new ChessBoardImpl();
        ChessFactoryImpl factory = new ChessFactoryImpl();
        instance.setChessFactory(factory);
        instance.resetBoard();
        Location fromLocation = factory.makeLocation(1, 0);
        Location toLocation = factory.makeLocation(3, 0);
        assertNull(instance.getPieceAtLocation(toLocation));
        assertNotNull(instance.getPieceAtLocation(fromLocation));
        instance.moveChessPiece(fromLocation, toLocation);
        assertNull(instance.getPieceAtLocation(fromLocation));
        assertNotNull(instance.getPieceAtLocation(toLocation));
    }

    /**
     * Test of removeChessPiece method, of class ChessBoardImpl.
     */
    @Test
    public void testRemoveChessPiece() {
        System.out.println("removeChessPiece");
        ChessBoardImpl instance = new ChessBoardImpl();
        ChessFactoryImpl factory = new ChessFactoryImpl();
        instance.setChessFactory(factory);
        instance.resetBoard();
        Location location = instance.getLocationAtIds(0,0);
        assertNotNull(location.getPiece());
        instance.removeChessPiece(location);
        assertNull(location.getPiece());
    }

    /**
     * Test of resetBoard method, of class ChessBoardImpl.
     */
    @Test
    public void testResetBoard() {
        System.out.println("resetBoard");
        ChessBoardImpl instance = new ChessBoardImpl();
        ChessFactoryImpl factory = new ChessFactoryImpl();
        instance.setChessFactory(factory);
        instance.resetBoard();
        Location[][] expResult = null;

        Location[][] result = instance.getAllLocations();
        _assertStandardLocations(result);

        Location fromLocation = factory.makeLocation(1, 0);
        Location toLocation = factory.makeLocation(3, 0);
        instance.moveChessPiece(fromLocation, toLocation);
        instance.resetBoard();
        _assertStandardLocations(result);
    }
}