/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author vji
 */
public class PieceImplTest {

    public PieceImplTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of setTeam method, of class PieceImpl.
     */
    @Test
    public void testSetTeam() {
        System.out.println("setTeam");
        Team team = Team.BLACK;
        ChessFactoryImpl factory = new ChessFactoryImpl();
        KingPiece instance = factory.makeKingPiece(team);
        PieceImpl pieceImpl = (PieceImpl) instance;
        pieceImpl.setTeam(team);
        assertEquals(team, pieceImpl.getTeam());
    }

    /**
     * Test of getTeam method, of class PieceImpl.
     */
    @Test
    public void testGetTeam() {
        System.out.println("getTeam");
        Team team = Team.BLACK;
        ChessFactoryImpl factory = new ChessFactoryImpl();
        KingPiece instance = factory.makeKingPiece(team);
        PieceImpl pieceImpl = (PieceImpl) instance;
        pieceImpl.setTeam(team);
        assertEquals(team, pieceImpl.getTeam());
    }

    /**
     * Test of equals method, of class PieceImpl.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        Team team = Team.BLACK;
        ChessFactoryImpl factory = new ChessFactoryImpl();
        KingPiece instance1 = factory.makeKingPiece(team);
        KingPiece instance2 = factory.makeKingPiece(team);
        PieceImpl pieceImpl1 = (PieceImpl) instance1;
        PieceImpl pieceImpl2 = (PieceImpl) instance2;
        assert(pieceImpl1.equals(pieceImpl2));
    }

    public class PieceImplImpl extends PieceImpl {
    }

}