/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;
import java.util.*;

/**
 *
 * @author vji
 */
public interface ChessBoard {

  Location [][] getAllLocations();
  
  Location getLocationAtIds(int rowId, int colId);

  Piece getPieceAtLocation(Location location);

  Class typeOfPieceAtLocation(Location location);

  void moveChessPiece(Location fromLocation, Location toLocation);

  void removeChessPiece(Location location);

  void resetBoard();
}
