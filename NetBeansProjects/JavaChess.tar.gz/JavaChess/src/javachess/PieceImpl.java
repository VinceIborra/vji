/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

/**
 *
 * @author vji
 */
abstract public class PieceImpl implements Piece {

    private Team     team;

    public void setTeam(Team team) {
        this.team = team;
    }
    public Team getTeam() {
        return team;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null
        ||  obj.getClass() != this.getClass()) {
            return false;
        }

        PieceImpl piece = (PieceImpl) obj;
        if (piece.getTeam() != this.getTeam()) {
            return false;
        }

        return true;
    }

}
