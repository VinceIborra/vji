/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;
import java.util.*;

/**
 *
 * @author vji
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Bean wiring
        ChessFactoryImpl chessFactory = new ChessFactoryImpl();
        ChessBoardImpl chessBoardImpl = new ChessBoardImpl();
        ChessBoard chessBoard = chessBoardImpl;
        chessBoardImpl.setChessFactory(chessFactory);
        ChessBoardRenderer chessBoardRenderer = new ChessBoardRendererImpl();

        // Initialisation
        chessBoard.resetBoard();

        // Print help commands
        System.out.println("Commands:");
        System.out.println("  move fromRow fromCol toRow toCol");
        System.out.println("  remove row col");
        System.out.println("  reset");
        System.out.println("  exit");
        System.out.print("\n");

        // Process User Commands until we're done
        Scanner in = new Scanner(System.in);
        boolean done = false;
        String message = "";
        while (!done) {

            chessBoardRenderer.render(chessBoard.getAllLocations());
            if (!message.equals("")) {
                System.out.println("\nError: " + message);
            }
            System.out.println("\n");
            System.out.print("Enter next move: ");

            try {

                String input = in.nextLine();
                String normalisedInput = input.toLowerCase();
                String tokens[] = normalisedInput.split("[ ]+");

                if (tokens[0].equals("move")) {
                    Location fromLocation = chessBoard.getLocationAtIds(
                        Integer.valueOf(tokens[1])-1,
                        Integer.valueOf(tokens[2])-1
                    );
                    Location toLocation =  chessBoard.getLocationAtIds(
                        Integer.valueOf(tokens[3])-1,
                        Integer.valueOf(tokens[4])-1
                    );
                    chessBoard.moveChessPiece(fromLocation, toLocation);
                }
                else if (tokens[0].equals("remove")) {
                    Location location = chessFactory.makeLocation(
                        Integer.valueOf(tokens[1])-1,
                        Integer.valueOf(tokens[2])-1
                    );
                    chessBoard.removeChessPiece(location);
                }
                else if (tokens[0].equals("reset")) {
                    chessBoard.resetBoard();
                }
                else if (tokens[0].equals("exit")) {
                    done = true;
                }
            }
            catch (InvalidIdsException exception) {
                message = "Incorrect ids specified";
            }
            catch (Throwable exception) {
                message = exception.toString();
            }
        }
    }
}
