/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

/**
 *
 * @author vji
 */
public interface Location {

  public int getRowId();

  public int getColId();

  public void  setPiece(Piece piece);
  public Piece getPiece();
}
