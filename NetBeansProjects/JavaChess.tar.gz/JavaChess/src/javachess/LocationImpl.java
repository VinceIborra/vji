/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

/**
 *
 * @author vji
 */
public class LocationImpl implements Location {

    private int   rowId;
    private int   colId;
    private Piece piece;

    public void setRowId(int rowId) {
        this.rowId = rowId;
    }
    public int  getRowId() {
        return rowId;
    }

    public void setColId(int colId) {
        this.colId = colId;
    }
    public int  getColId() {
        return colId;
    }

    public void setPiece(Piece piece) {
        this.piece = piece;
    }
    public Piece getPiece() {
        return piece;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null
        ||  obj.getClass() != this.getClass()) {
            return false;
        }

        LocationImpl location = (LocationImpl) obj;
        if (location.getColId() != this.getColId()
        ||  location.getRowId() != this.getRowId()) {
            return false;
        }

        if (this.getPiece() == null && location.getPiece() == null) {
            return true;
        }
        else if ((this.getPiece() != null && location.getPiece() == null)
        ||       (this.getPiece() == null && location.getPiece() != null)) {
            return false;
        }
        else {
            return location.getPiece().equals(this.getPiece());
        }        
    }
}
