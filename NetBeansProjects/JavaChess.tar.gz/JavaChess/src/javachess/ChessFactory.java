/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

/**
 *
 * @author vji
 */
public interface ChessFactory {

  KingPiece   makeKingPiece  (Team team);
  QueenPiece  makeQueenPiece (Team team);
  BishopPiece makeBishopPiece(Team team);
  KnightPiece makeKnightPiece(Team team);
  RookPiece   makeRookPiece (Team team);
  PawnPiece   makePawnPiece (Team team);

  Location    makeLocation(int rowId, int colId);  
}
