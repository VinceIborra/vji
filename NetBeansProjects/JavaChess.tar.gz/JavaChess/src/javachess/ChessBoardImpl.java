/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;
import java.util.*;

/**
 *
 * @author vji
 */
public class ChessBoardImpl implements ChessBoard {

    final int BOARD_SIZE = 8;

    ChessFactory chessFactory;
    Location [][] boardLocations = new Location[BOARD_SIZE][BOARD_SIZE];

    public ChessBoardImpl() {
    }

    public void setChessFactory(ChessFactory chessFactory) {
        this.chessFactory = chessFactory;
    }
    public ChessFactory getChessFactory() {
        return this.chessFactory;
    }

    public Location[][] getAllLocations() {
        return boardLocations;
    }

    public Location getLocationAtIds(int rowId, int colId) {
        _assertValidIds(rowId, colId);
        return boardLocations[rowId][colId];
    }

    public Piece getPieceAtLocation(Location location) {
      _assertValidLocation(location);
      return boardLocations[location.getRowId()][location.getColId()].getPiece();
    }

    public Class typeOfPieceAtLocation(Location location) {
        Piece piece = getPieceAtLocation(location);
        if      (piece instanceof KingPiece)   { return KingPiece.class;   }
        else if (piece instanceof QueenPiece)  { return QueenPiece.class;  }
        else if (piece instanceof BishopPiece) { return BishopPiece.class; }
        else if (piece instanceof KnightPiece) { return KnightPiece.class; }
        else if (piece instanceof RookPiece)   { return RookPiece.class;   }
        else if (piece instanceof PawnPiece)   { return PawnPiece.class;   }
        else                                   { return null;              }
    }

    public void moveChessPiece(Location fromLocation, Location toLocation) {
      _assertValidLocation(fromLocation);
      _assertValidLocation(toLocation);
      this.removeChessPiece(toLocation);
      Location boardFromLocation = this.getLocationAtIds(fromLocation.getRowId(), fromLocation.getColId());
      Location boardToLocation = this.getLocationAtIds(toLocation.getRowId(), toLocation.getColId());
      boardLocations[toLocation.getRowId()][toLocation.getColId()].setPiece(boardFromLocation.getPiece());
      boardLocations[fromLocation.getRowId()][fromLocation.getColId()].setPiece(null);
    }

    public void removeChessPiece(Location location) {
        _assertValidLocation(location);
        boardLocations[location.getRowId()][location.getColId()].setPiece(null);
    }

    private void _initialiseLocations() {
        int idx;
        int jdx;
        for (idx=0; idx<BOARD_SIZE; idx++) {
            for (jdx=0; jdx<BOARD_SIZE; jdx++) {
                if (boardLocations[idx][jdx] == null) {
                    boardLocations[idx][jdx] = chessFactory.makeLocation(idx, jdx);
                }
            }
        }
    }

    public void resetBoard() {

        _initialiseLocations();

        int idx;
        int jdx;
        for (idx=0; idx<BOARD_SIZE; idx++) {
            for (jdx=0; jdx<BOARD_SIZE; jdx++) {
                if (boardLocations[idx][jdx].getPiece() != null) {
                    boardLocations[idx][jdx].setPiece(null);
                }
            }
        }

        boardLocations[0][0].setPiece(chessFactory.makeRookPiece(Team.BLACK));
        boardLocations[0][1].setPiece(chessFactory.makeKnightPiece(Team.BLACK));
        boardLocations[0][2].setPiece(chessFactory.makeBishopPiece(Team.BLACK));
        boardLocations[0][3].setPiece(chessFactory.makeQueenPiece(Team.BLACK));
        boardLocations[0][4].setPiece(chessFactory.makeKingPiece(Team.BLACK));
        boardLocations[0][5].setPiece(chessFactory.makeBishopPiece(Team.BLACK));
        boardLocations[0][6].setPiece(chessFactory.makeKnightPiece(Team.BLACK));
        boardLocations[0][7].setPiece(chessFactory.makeRookPiece(Team.BLACK));
        boardLocations[1][0].setPiece(chessFactory.makePawnPiece(Team.BLACK));
        boardLocations[1][1].setPiece(chessFactory.makePawnPiece(Team.BLACK));
        boardLocations[1][2].setPiece(chessFactory.makePawnPiece(Team.BLACK));
        boardLocations[1][3].setPiece(chessFactory.makePawnPiece(Team.BLACK));
        boardLocations[1][4].setPiece(chessFactory.makePawnPiece(Team.BLACK));
        boardLocations[1][5].setPiece(chessFactory.makePawnPiece(Team.BLACK));
        boardLocations[1][6].setPiece(chessFactory.makePawnPiece(Team.BLACK));
        boardLocations[1][7].setPiece(chessFactory.makePawnPiece(Team.BLACK));

        boardLocations[6][0].setPiece(chessFactory.makePawnPiece(Team.WHITE));
        boardLocations[6][1].setPiece(chessFactory.makePawnPiece(Team.WHITE));
        boardLocations[6][2].setPiece(chessFactory.makePawnPiece(Team.WHITE));
        boardLocations[6][3].setPiece(chessFactory.makePawnPiece(Team.WHITE));
        boardLocations[6][4].setPiece(chessFactory.makePawnPiece(Team.WHITE));
        boardLocations[6][5].setPiece(chessFactory.makePawnPiece(Team.WHITE));
        boardLocations[6][6].setPiece(chessFactory.makePawnPiece(Team.WHITE));
        boardLocations[6][7].setPiece(chessFactory.makePawnPiece(Team.WHITE));
        boardLocations[7][0].setPiece(chessFactory.makeRookPiece(Team.WHITE));
        boardLocations[7][1].setPiece(chessFactory.makeKnightPiece(Team.WHITE));
        boardLocations[7][2].setPiece(chessFactory.makeBishopPiece(Team.WHITE));
        boardLocations[7][3].setPiece(chessFactory.makeQueenPiece(Team.WHITE));
        boardLocations[7][4].setPiece(chessFactory.makeKingPiece(Team.WHITE));
        boardLocations[7][5].setPiece(chessFactory.makeBishopPiece(Team.WHITE));
        boardLocations[7][6].setPiece(chessFactory.makeKnightPiece(Team.WHITE));
        boardLocations[7][7].setPiece(chessFactory.makeRookPiece(Team.WHITE));
    }

    private void _assertValidIds(int rowId, int colId) {
        if (rowId < 0 || rowId >= BOARD_SIZE
        ||  colId < 0 || colId >= BOARD_SIZE) {
            throw new InvalidIdsException();
        }
    }

    private void _assertValidLocation(Location location) {
        _assertValidIds(location.getRowId(), location.getColId());
    }
}

