/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

/**
 *
 * @author vji
 */
public class ChessFactoryImpl implements ChessFactory {

    public Location makeLocation(int rowId, int colId) {
        LocationImpl location = new LocationImpl();
        location.setRowId(rowId);
        location.setColId(colId);
        return location;
    }

    public KingPiece makeKingPiece(Team team) {
        KingPieceImpl piece = new KingPieceImpl();
        piece.setTeam(team);
        return piece;
    }

    public QueenPiece makeQueenPiece(Team team) {
        QueenPieceImpl piece = new QueenPieceImpl();
        piece.setTeam(team);
        return piece;
    }

    public BishopPiece makeBishopPiece(Team team) {
        BishopPieceImpl piece = new BishopPieceImpl();
        piece.setTeam(team);
        return piece;
    }

    public KnightPiece makeKnightPiece(Team team) {
        KnightPieceImpl piece = new KnightPieceImpl();
        piece.setTeam(team);
        return piece;
    }

    public RookPiece makeRookPiece(Team team) {
        RookPieceImpl piece = new RookPieceImpl();
        piece.setTeam(team);
        return piece;
    }

    public PawnPiece makePawnPiece(Team team) {
        PawnPieceImpl piece = new PawnPieceImpl();
        piece.setTeam(team);
        return piece;
    }

}
