/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javachess;

/**
 *
 * @author vji
 */
class ChessBoardRendererImpl implements ChessBoardRenderer {

    public ChessBoardRendererImpl() {
    }

    private void _renderPiece(Piece piece) {
        if (piece == null) {
            System.out.print(' ');
        }
        else if (piece instanceof KingPiece){
            if (piece.getTeam() == Team.BLACK) {
                System.out.print('K');
            }
            else {
                System.out.print('k');
            }
        }
        else if (piece instanceof QueenPiece){
            if (piece.getTeam() == Team.BLACK) {
                System.out.print('Q');
            }
            else {
                System.out.print('q');
            }
        }
        else if (piece instanceof BishopPiece){
            if (piece.getTeam() == Team.BLACK) {
                System.out.print('B');
            }
            else {
                System.out.print('b');
            }
        }
        else if (piece instanceof KnightPiece){
            if (piece.getTeam() == Team.BLACK) {
                System.out.print('N');
            }
            else {
                System.out.print('n');
            }
        }
        else if (piece instanceof RookPiece){
            if (piece.getTeam() == Team.BLACK) {
                System.out.print('R');
            }
            else {
                System.out.print('r');
            }
        }
        else if (piece instanceof PawnPiece){
            if (piece.getTeam() == Team.BLACK) {
                System.out.print('P');
            }
            else {
                System.out.print('p');
            }
        }
    }

    public void render(Location[][] board) {
        int idx;
        int jdx;
        System.out.println("  12345678");
        for (idx=0; idx<8; idx++) {
            System.out.print(idx+1);
            System.out.print(' ');
            for (jdx=0; jdx<8; jdx++) {
                this._renderPiece(board[idx][jdx].getPiece());
            }
            System.out.println(' ');
        }
    }
}
