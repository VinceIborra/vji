java -cp ./dist/MarsRovers.jar com.tw.marsrover.Main InputFile.txt
