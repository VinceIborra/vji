package com.tw.marsrover;

/**
 *
 * @author vji
 */
public interface PlateauRenderer {
    public void render();
}
