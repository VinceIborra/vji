package com.tw.marsrover;

/**
 *
 * @author vji
 */
public interface PositionAndOrientation {
    int getX();
    int getY();
    Orientation getOrientation();
}
