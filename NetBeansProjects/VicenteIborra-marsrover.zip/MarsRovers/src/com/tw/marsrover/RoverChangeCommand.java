package com.tw.marsrover;

/**
 *
 * @author vji
 */
public interface RoverChangeCommand extends Command {
}
