package com.tw.marsrover;

/**
 *
 * @author vji
 */
public interface RoverTurnRightCommand extends RoverChangeCommand {

}
