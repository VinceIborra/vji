package com.tw.marsrover;

import java.util.*;

/**
 *
 * @author vji
 */
public interface Plateau {

  void setX(int x);
  int getX();
  void setY(int y);
  int getY();

  void startNewRover(Rover rover);
  Rover getCurrentRover();

  List<Rover> getRovers();

  void assertValidPositionAndOrientation(PositionAndOrientation positionAndOrientation);
}
