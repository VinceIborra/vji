package com.tw.marsrover;

/**
 *
 * @author vji
 */
public interface PlateauChangeCommand extends Command {
  int getX();
  int getY();
}
