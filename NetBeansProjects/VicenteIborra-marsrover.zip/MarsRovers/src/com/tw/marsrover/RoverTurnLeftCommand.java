package com.tw.marsrover;

/**
 *
 * @author vji
 */
public interface RoverTurnLeftCommand extends RoverChangeCommand {

}
