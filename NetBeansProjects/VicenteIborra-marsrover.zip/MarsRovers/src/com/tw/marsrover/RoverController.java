package com.tw.marsrover;

/**
 *
 * @author vji
 */
public interface RoverController {
    void processCommand(Command command);
}
