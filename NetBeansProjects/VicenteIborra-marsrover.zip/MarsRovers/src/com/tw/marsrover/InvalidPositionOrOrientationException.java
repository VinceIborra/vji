package com.tw.marsrover;

/**
 *
 * @author vji
 */
public class InvalidPositionOrOrientationException extends RuntimeException {
  public InvalidPositionOrOrientationException(String message) {
      super(message);
  }
}
