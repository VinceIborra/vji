package com.tw.marsrover;

/**
 *
 * @author vji
 */
public interface RoverMoveCommand extends RoverChangeCommand {

}
