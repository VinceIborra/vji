package com.tw.marsrover;

/**
 *
 * @author vji
 */
public class UninitialisedPlateauException extends RuntimeException {
  public UninitialisedPlateauException(String message) {
      super(message);
  }
}
