java -cp ./dist/MarsRovers.jar com.tw.marsrover.Main InputFile_BadCommand.txt
java -cp ./dist/MarsRovers.jar com.tw.marsrover.Main InputFile_BadRoverChange.txt
java -cp ./dist/MarsRovers.jar com.tw.marsrover.Main InputFile_MissingPlateauSizeSet.txt
java -cp ./dist/MarsRovers.jar com.tw.marsrover.Main InputFile_MissingRoverSet.txt
java -cp ./dist/MarsRovers.jar com.tw.marsrover.Main InputFile_MoveRoverOffPlateau.txt
